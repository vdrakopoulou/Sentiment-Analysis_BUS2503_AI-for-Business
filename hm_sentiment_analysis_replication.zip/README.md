
# H&M Seasonal Campaign Sentiment Analysis – Replication Package (Template)

This package is a **learning template** for the BUS2503 – AI for Business case study
"H&M Seasonal Campaign Sentiment Analysis". You should **adapt, extend, and comment**
the code and workflow yourself to meet your course requirements.

## Folder Contents

- `hm_sentiment_analysis_template.py`  
  Python script with a simple TF–IDF + Logistic Regression sentiment classifier
  for `H&M_sentiment_reviews.csv`.
- `requirements.txt`  
  Minimal Python dependencies.
- `knime_workflow_steps.txt`  
  Step-by-step description of how to build an equivalent workflow in KNIME Analytics Platform.
- `README.md`  
  This file.

---

## 1. Expected Data

Place your dataset file in the **same folder** as the script and name it:

- `H&M_sentiment_reviews.csv`

The file should contain (at least) the following columns:

- `comment_text` – text of the customer comment
- `sentiment` – sentiment label (`Positive`, `Neutral`, `Negative`)
- `platform` – (optional) source platform (`Instagram`, `X`, `Facebook`, etc.)

If your file uses different column names, edit the script accordingly.

---

## 2. Running Locally (Python)

1. Create and activate a virtual environment (optional but recommended).
2. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

3. Make sure `H&M_sentiment_reviews.csv` is in the same folder.
4. Run the script:

   ```bash
   python hm_sentiment_analysis_template.py
   ```

The script will:

- Load the CSV file.
- Split data into train and test sets.
- Build a TF–IDF + Logistic Regression pipeline.
- Train the model.
- Print overall accuracy, classification report and confusion matrix.
- Optionally print **per-platform accuracy** if the `platform` column exists.

---

## 3. Using in Google Colab

1. Go to [Google Colab](https://colab.research.google.com) and create a new notebook.
2. Upload:
   - `hm_sentiment_analysis_template.py`
   - `H&M_sentiment_reviews.csv`
   - (optionally) `requirements.txt`
3. In the first cell, install libraries (only needed once per session):

   ```python
   !pip install -r requirements.txt
   ```

4. In the next cell, run:

   ```python
   import hm_sentiment_analysis_template as hm
   hm.main()
   ```

You can also just copy-paste code from the script into Colab cells and run them step by step.

---

## 4. KNIME Workflow (High-Level)

The `knime_workflow_steps.txt` file describes how to build a very similar workflow in KNIME.

Typical building blocks:

1. Read CSV
2. Text preprocessing (tokenization, case conversion, stop-word filter, punctuation removal)
3. Create document and bag-of-words
4. TF–IDF calculation
5. Train/test split
6. Machine learning classifier (e.g., Logistic Regression, Naive Bayes)
7. Scorer node for evaluation (accuracy, confusion matrix)

---

## 5. Reminder

This package is a **template** to help you understand the workflow. For your course work:

- Explain each step in your own words.
- Experiment with parameters (e.g., different classifiers, n-grams, max_features).
- Add your own plots, error analysis, and discussion of business insights.
- Follow your instructor’s guidelines on academic integrity.
