"""H&M Seasonal Campaign Sentiment Analysis Template

This script provides a simple baseline sentiment analysis pipeline for the
BUS2503 case study. It is meant as a learning template – adapt and extend it
for your own analysis and commentary.

Steps:
1. Load the labelled H&M sentiment dataset from CSV.
2. Split into train/test sets.
3. Build a TF–IDF + Logistic Regression pipeline.
4. Train the model and evaluate accuracy and classification metrics.
5. Optionally report accuracy by social media platform.

Expected columns in the CSV:
- comment_text
- sentiment
- platform (optional)
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score


def load_data(csv_path: str = "H&M_sentiment_reviews.csv") -> pd.DataFrame:
    """
    Load the H&M sentiment dataset from a CSV file.
    """
    df = pd.read_csv(csv_path)

    expected_cols = {"comment_text", "sentiment"}
    missing = expected_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing expected columns in CSV: {missing}")

    # Drop rows with missing text or label
    df = df.dropna(subset=["comment_text", "sentiment"])
    return df


def build_pipeline() -> Pipeline:
    """
    Build a simple TF–IDF + Logistic Regression classification pipeline.
    """
    text_clf = Pipeline(
        steps=[
            (
                "tfidf",
                TfidfVectorizer(
                    max_features=10000,
                    ngram_range=(1, 2),  # unigrams + bigrams
                    stop_words="english",
                ),
            ),
            (
                "clf",
                LogisticRegression(
                    max_iter=1000,
                    n_jobs=None,
                ),
            ),
        ]
    )
    return text_clf


def evaluate_model(model: Pipeline, X_test, y_test) -> None:
    """
    Print accuracy, classification report and confusion matrix.
    """
    y_pred = model.predict(X_test)

    print("=== Evaluation on Test Set ===")
    print(f"Accuracy: {accuracy_score(y_test, y_pred):.3f}\n")
    print("Classification report:")
    print(classification_report(y_test, y_pred))
    print("Confusion matrix:")
    print(confusion_matrix(y_test, y_pred))


def per_platform_accuracy(df: pd.DataFrame, model: Pipeline) -> None:
    """
    Compute and print accuracy by platform (if 'platform' column exists).
    """
    if "platform" not in df.columns:
        print("\nNo 'platform' column found. Skipping per-platform analysis.")
        return

    print("\n=== Per-platform accuracy (simple re-split within each platform) ===")
    platforms = df["platform"].dropna().unique()

    for platform in platforms:
        subset = df[df["platform"] == platform]
        if len(subset) < 20:
            # too few rows for a stable estimate
            print(f"{platform}: not enough examples ({len(subset)})")
            continue

        X_p = subset["comment_text"].astype(str)
        y_p = subset["sentiment"].astype(str)

        X_train_p, X_test_p, y_train_p, y_test_p = train_test_split(
            X_p,
            y_p,
            test_size=0.2,
            random_state=42,
            stratify=y_p,
        )

        # Fit a fresh copy of the model on the platform subset for a fair comparison
        local_model = build_pipeline()
        local_model.fit(X_train_p, y_train_p)
        acc = accuracy_score(y_test_p, local_model.predict(X_test_p))
        print(f"{platform}: {acc:.3f}")


def main():
    # 1. Load data
    csv_path = "H&M_sentiment_reviews.csv"
    print(f"Loading data from: {csv_path}")
    df = load_data(csv_path)

    print("\nSample of the data:")
    print(df.head())

    # 2. Prepare features and labels
    X = df["comment_text"].astype(str)
    y = df["sentiment"].astype(str)

    # 3. Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42,
        stratify=y,
    )

    # 4. Build and train model
    model = build_pipeline()
    print("\nTraining model...")
    model.fit(X_train, y_train)
    print("Training complete.")

    # 5. Evaluate
    evaluate_model(model, X_test, y_test)

    # 6. Optional: per-platform breakdown
    per_platform_accuracy(df, model)


if __name__ == "__main__":
    main()
